import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int a = rnd.nextInt(1,10);
        int b = rnd.nextInt(1,10);
        System.out.println("Введите результат умножения "+a+" и "+b);
        Scanner scr = new Scanner(System.in);
        int c = scr.nextInt();
        int t = a*b;
        System.out.println(t==c ? " Ваш ответ "+c+" Все верно" : " Ваш ответ "+c+" Вы ошиблись правильный ответ равен "+t);


    }
}
//Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
// Программа генерирует два целых однозначных числа. Программа задаёт вопрос: результат умножения первого числа на второе?
// Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
// Если пользователь ответил неправильно, то программа должна показать правильный ответ.