public class Main {
    public static void main(String[] args) {
        double n = Math.random()*100;
        double m = Math.random()*100;
        System.out.println("Первое число равно "+ n);
        System.out.println("Второе число равно "+ m);
        double distN = Math.abs(10-n);
        double distM = Math.abs(10-m);
        System.out.print("Ближайшее к 10 число это: ");
        System.out.println(distN<distM ? n : m);


    }
}
//Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
//Числа могут быть, как целочисленные, так и дробные.