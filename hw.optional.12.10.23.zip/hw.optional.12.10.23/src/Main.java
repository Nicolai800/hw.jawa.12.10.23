import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Ввидите номер дня недели");
        Scanner scr = new Scanner(System.in);
        int d = scr.nextInt();
        System.out.print( d==1 ? "Понедельник" : "");
        System.out.print( d==2 ? "Вторник" : "");
        System.out.print( d==3 ? "Среда" : "");
        System.out.print( d==4 ? "Четверг" : "");
        System.out.print( d==5 ? "Пятница" : "");
        System.out.print( d==6 ? "Суббота" : "");
        System.out.print( d==7 ? "Воскресенье" : "");
        System.out.print((d<1 || d>7) ? "Номер дня введен некорректно" : "" );

    }
}
// Введен номер дня недели. Выведите название дня недели. Если номер дня введен некорректно,
// то выведите соответствующие сообщение и завершите программу.